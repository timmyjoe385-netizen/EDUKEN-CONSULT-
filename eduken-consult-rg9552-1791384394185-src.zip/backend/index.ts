import { router, json, error, requireAuth, requireAdminEmailAllowlist } from '@appdeploy/sdk';
import { db } from '@appdeploy/sdk';
import { realtimeSubscriptionRoutes } from './realtime-subscribers';
import { platformRoutes } from './platform';

const ADMIN_EMAILS = ['timmyjoe385@gmail.com', 'edukenconsult00@gmail.com'];

type RecordData = Record<string, unknown>;

const seeds: Record<string, RecordData[]> = {
  opportunities: [
    { title: 'Opportunity listings coming soon', category: 'All', description: 'Verified opportunities will appear here.', deadline: 'Stay tuned', status: 'Published', link: '' },
    { title: 'Scholarship opportunities', category: 'Scholarships', description: 'Browse funding opportunities when published.', deadline: 'Upcoming', status: 'Published', link: '' },
    { title: 'Jobs & internships', category: 'Jobs', description: 'Student and graduate opportunities will be listed here.', deadline: 'Upcoming', status: 'Published', link: '' },
    { title: 'Remote opportunities', category: 'Remote', description: 'Remote opportunities curated for young people.', deadline: 'Upcoming', status: 'Published', link: '' }
  ],
  admissions: [
    { school: 'Nigerian Universities', type: 'University', course: 'Admission information', status: 'UPCOMING', deadline: 'Updates will be published', details: '', link: '' },
    { school: 'Polytechnics', type: 'Polytechnic', course: 'Application information', status: 'UPCOMING', deadline: 'Updates will be published', details: '', link: '' },
    { school: 'Colleges of Education', type: 'College of Education', course: 'Programme information', status: 'UPCOMING', deadline: 'Updates will be published', details: '', link: '' }
  ],
  updates: [
    { category: 'Admissions', title: 'Verified admission updates will appear here.', body: 'Use the EDUKEN admin dashboard to publish clear, useful updates.', status: 'Published', date: '2026-10-07' },
    { category: 'Opportunities', title: 'New opportunities will be published here.', body: 'Add scholarships, jobs, internships, grants, fellowships and competitions from the dashboard.', status: 'Published', date: '2026-10-07' },
    { category: 'Career', title: 'Career and mentorship updates will appear here.', body: 'Publish practical career guidance and development opportunities.', status: 'Published', date: '2026-10-07' }
  ],
  faqs: [
    { question: 'What does EDUKEN CONSULT do?', answer: 'EDUKEN CONSULT provides educational updates, admissions information, opportunity discovery and practical guidance for students and applicants.', status: 'Published' },
    { question: 'How can I request a consultation?', answer: 'Use the consultation form or contact EDUKEN CONSULT directly on WhatsApp.', status: 'Published' },
    { question: 'How do I find admission updates?', answer: 'Browse the Admission Hub. Critical requirements and deadlines should always be confirmed with the relevant official institution.', status: 'Published' },
    { question: 'How do I find scholarships and opportunities?', answer: 'Use the EDUKEN Opportunity Hub and its category filters.', status: 'Published' },
    { question: 'Are opportunities verified?', answer: 'EDUKEN aims to publish useful and verified information, while users should confirm final requirements and deadlines with the official provider.', status: 'Published' }
  ],
  services: [
    { name: 'Admission Guidance', status: 'Published' },
    { name: 'School Application Assistance', status: 'Published' },
    { name: 'Change of Institution/Course Guidance', status: 'Published' },
    { name: 'Screening/Application Support', status: 'Published' },
    { name: 'Result & Document Services', status: 'Published' },
    { name: 'Educational Consultation', status: 'Published' },
    { name: 'Admission/School Research', status: 'Published' },
    { name: 'Career & Opportunity Guidance', status: 'Published' },
    { name: 'Student Mentorship', status: 'Published' }
  ]
};

async function ensureSeeded(table: string) {
  const page = await db.list(table, { limit: 1 });
  if (page.items.length === 0 && seeds[table]) {
    await db.add(table, seeds[table]);
  }
}

async function listTable(table: string) {
  await ensureSeeded(table);
  const page = await db.list<RecordData>(table, { limit: 100 });
  return page.items;
}

function admin() {
  return [requireAuth(), requireAdminEmailAllowlist(ADMIN_EMAILS)];
}

function validTable(table: string) {
  return ['opportunities', 'admissions', 'updates', 'faqs', 'services'].includes(table);
}

export const handler = router({
  'GET /api/_healthcheck': [async () => json({ message: 'Success' })],

  'GET /api/public-content': [async () => {
    const [opportunities, admissions, updates, faqs, services] = await Promise.all([
      listTable('opportunities'),
      listTable('admissions'),
      listTable('updates'),
      listTable('faqs'),
      listTable('services')
    ]);
    return json({ opportunities, admissions, updates, faqs, services });
  }],

  'POST /api/consultations': [async ({ body }) => {
    const data = (body || {}) as RecordData;
    if (!data.name || !data.whatsapp || !data.message) return error('Name, WhatsApp number and message are required.', 400);
    const [id] = await db.add('consultations', [{
      name: data.name,
      whatsapp: data.whatsapp,
      email: data.email || '',
      state: data.state || '',
      educationLevel: data.educationLevel || '',
      interest: data.interest || '',
      schoolCourse: data.schoolCourse || '',
      message: data.message,
      status: 'New',
      createdAt: new Date().toISOString()
    }]);
    if (!id) return error('Unable to save consultation request.', 500);
    return json({ id, message: 'Consultation request received.' }, 201);
  }],

  'GET /api/admin/content/:table': admin().concat([async ({ params }) => {
    if (!validTable(params.table)) return error('Unknown content type.', 404);
    return json({ items: await listTable(params.table) });
  }]),

  'POST /api/admin/content/:table': admin().concat([async ({ params, body }) => {
    if (!validTable(params.table)) return error('Unknown content type.', 404);
    const data = (body || {}) as RecordData;
    if (!Object.keys(data).length) return error('Content is required.', 400);
    const [id] = await db.add(params.table, [data]);
    if (!id) return error('Unable to create content.', 500);
    return json({ id }, 201);
  }]),

  'PUT /api/admin/content/:table/:id': admin().concat([async ({ params, body }) => {
    if (!validTable(params.table)) return error('Unknown content type.', 404);
    const existing = await db.get<RecordData>(params.table, [params.id]);
    if (!existing[0]) return error('Record not found.', 404);
    const data = (body || {}) as RecordData;
    const ok = await db.update(params.table, [{ id: params.id, record: data }]);
    if (!ok[0]) return error('Unable to update content.', 500);
    return json({ ok: true });
  }]),

  'DELETE /api/admin/content/:table/:id': admin().concat([async ({ params }) => {
    if (!validTable(params.table)) return error('Unknown content type.', 404);
    const ok = await db.delete(params.table, [params.id]);
    if (!ok[0]) return error('Unable to delete content.', 500);
    return json({ ok: true });
  }]),

  'GET /api/admin/consultations': admin().concat([async () => {
    const page = await db.list<RecordData>('consultations', { limit: 100 });
    return json({ items: page.items });
  }]),

  'PUT /api/admin/consultations/:id': admin().concat([async ({ params, body }) => {
    const existing = await db.get<RecordData>('consultations', [params.id]);
    if (!existing[0]) return error('Consultation not found.', 404);
    const data = (body || {}) as RecordData;
    const ok = await db.update('consultations', [{ id: params.id, record: { ...existing[0], ...data } }]);
    if (!ok[0]) return error('Unable to update consultation.', 500);
    return json({ ok: true });
  }]),

  ...platformRoutes,
  ...realtimeSubscriptionRoutes
});
