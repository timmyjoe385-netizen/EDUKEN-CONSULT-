import { db, notifications, ai, requireAuth, json, error } from '@appdeploy/sdk';

type RecordData = Record<string, unknown>;

const scoped = async (table: string, userId: string) => {
  const page = await db.list<RecordData>(table, { limit: 100 });
  return page.items.filter(item => item.userId === userId);
};

const topicName = (value: unknown) => 'eduken-' + String(value || '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');

export const platformRoutes = {
  'GET /api/me': [requireAuth(), async ({ user }) => {
    const rows = await scoped('profiles', user!.userId);
    return json({ user, profile: rows[0] || null });
  }],

  'PUT /api/me': [requireAuth(), async ({ user, body }) => {
    const data = (body || {}) as RecordData;
    const rows = await scoped('profiles', user!.userId);
    const record = { userId: user!.userId, displayName: String(data.displayName || '').slice(0, 80), updatedAt: new Date().toISOString() };
    if (rows[0]) {
      const ok = await db.update('profiles', [{ id: rows[0].id, record: { ...rows[0], ...record } }]);
      return ok[0] ? json({ profile: { ...rows[0], ...record } }) : error('Unable to update profile.', 500);
    }
    const [id] = await db.add('profiles', [record]);
    return id ? json({ profile: { id, ...record } }, 201) : error('Unable to create profile.', 500);
  }],

  'GET /api/user/saved': [requireAuth(), async ({ user }) => json({ items: await scoped('saved_opportunities', user!.userId) })],

  'POST /api/user/saved': [requireAuth(), async ({ user, body }) => {
    const data = (body || {}) as RecordData;
    const rows = await scoped('saved_opportunities', user!.userId);
    if (rows.some(item => item.opportunityId === data.opportunityId)) return json({ ok: true });
    const [id] = await db.add('saved_opportunities', [{
      userId: user!.userId, opportunityId: String(data.opportunityId || ''), title: String(data.title || ''),
      slug: String(data.slug || ''), createdAt: new Date().toISOString()
    }]);
    return id ? json({ id }, 201) : error('Unable to save opportunity.', 500);
  }],

  'DELETE /api/user/saved/:opportunityId': [requireAuth(), async ({ user, params }) => {
    const rows = await scoped('saved_opportunities', user!.userId);
    const ids = rows.filter(item => item.opportunityId === params.opportunityId).map(item => item.id);
    if (ids.length) await db.delete('saved_opportunities', ids);
    return json({ ok: true });
  }],

  'GET /api/user/tracker': [requireAuth(), async ({ user }) => json({ items: await scoped('application_tracker', user!.userId) })],

  'POST /api/user/tracker': [requireAuth(), async ({ user, body }) => {
    const data = (body || {}) as RecordData;
    const rows = await scoped('application_tracker', user!.userId);
    if (rows.some(item => item.opportunityId === data.opportunityId)) return json({ ok: true });
    const [id] = await db.add('application_tracker', [{
      userId: user!.userId, opportunityId: String(data.opportunityId || ''), title: String(data.title || ''),
      slug: String(data.slug || ''), status: String(data.status || 'Planning to Apply'),
      deadline: String(data.deadline || ''), notes: String(data.notes || ''), createdAt: new Date().toISOString()
    }]);
    return id ? json({ id }, 201) : error('Unable to add tracker item.', 500);
  }],

  'PUT /api/user/tracker/:id': [requireAuth(), async ({ user, params, body }) => {
    const rows = await scoped('application_tracker', user!.userId);
    const existing = rows.find(item => item.id === params.id);
    if (!existing) return error('Tracker item not found.', 404);
    const data = (body || {}) as RecordData;
    const ok = await db.update('application_tracker', [{
      id: existing.id, record: { ...existing, status: String(data.status || existing.status), notes: String(data.notes || '') }
    }]);
    return ok[0] ? json({ ok: true }) : error('Unable to update tracker.', 500);
  }],

  'GET /api/user/notifications': [requireAuth(), async ({ user }) => {
    const items = await scoped('notifications', user!.userId);
    items.sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)));
    return json({ items: items.slice(0, 50) });
  }],

  'POST /api/user/notifications/read': [requireAuth(), async ({ user, body }) => {
    const data = (body || {}) as RecordData;
    const rows = await scoped('notifications', user!.userId);
    const targets = rows.filter(item => data.all || item.id === data.id);
    if (targets.length) await db.update('notifications', targets.map(item => ({ id: item.id, record: { ...item, read: true } })));
    return json({ ok: true });
  }],

  'GET /api/user/topics': [requireAuth(), async ({ user }) => {
    const result = await notifications.listUserTopics({ userId: user!.userId });
    return json({ topics: result.topics.filter(x => x.startsWith('eduken-')).map(x => x.replace(/^eduken-/, '').replace(/-/g, ' ').replace(/\b\w/g, c => c.toUpperCase())) });
  }],

  'POST /api/user/topics/:action': [requireAuth(), async ({ user, params, body }) => {
    const topic = topicName(((body || {}) as RecordData).topic);
    if (topic === 'eduken-') return error('Topic is required.', 400);
    if (params.action === 'subscribe') await notifications.subscribeTopic({ userIds: [user!.userId], topic });
    else if (params.action === 'unsubscribe') await notifications.unsubscribeTopic({ userIds: [user!.userId], topic });
    else return error('Unknown topic action.', 400);
    return json({ ok: true });
  }],

  'POST /api/user/reminders/check': [requireAuth(), async ({ user }) => {
    const [savedPage, reminderPage, opportunityPage] = await Promise.all([
      db.list<RecordData>('saved_opportunities', { limit: 100 }),
      db.list<RecordData>('user_reminders', { limit: 200 }),
      db.list<RecordData>('opportunities', { limit: 100 })
    ]);
    const saved = savedPage.items.filter(item => item.userId === user!.userId);
    const reminders = reminderPage.items.filter(item => item.userId === user!.userId);
    const now = Date.now();

    for (const save of saved) {
      const opportunity = opportunityPage.items.find(item => item.id === save.opportunityId);
      if (!opportunity?.deadline) continue;
      const deadline = new Date(String(opportunity.deadline)).getTime();
      if (Number.isNaN(deadline) || deadline <= now) continue;
      const days = Math.ceil((deadline - now) / 864e5);
      const bucket = days <= 1 ? '1d' : days <= 3 ? '3d' : days <= 7 ? '7d' : '';
      if (!bucket || reminders.some(item => item.opportunityId === opportunity.id && item.bucket === bucket)) continue;
      const title = 'EDUKEN deadline reminder';
      const body = String(opportunity.title || 'Saved opportunity') + ' — ' + days + ' days left.';
      await db.add('notifications', [{ userId: user!.userId, title, body, read: false, createdAt: new Date().toISOString() }]);
      await notifications.send({ userIds: [user!.userId], notification: { title, body } }).catch(() => undefined);
      await db.add('user_reminders', [{ userId: user!.userId, opportunityId: opportunity.id, bucket, createdAt: new Date().toISOString() }]);
    }
    return json({ ok: true });
  }],

  'POST /api/ai-assistant': [async ({ body }) => {
    const question = String(((body || {}) as RecordData).question || '').trim();
    if (!question) return error('Question is required.', 400);
    const [opportunities, admissions, updates] = await Promise.all([
      db.list<RecordData>('opportunities', { limit: 40 }),
      db.list<RecordData>('admissions', { limit: 30 }),
      db.list<RecordData>('updates', { limit: 30 })
    ]);
    const context = JSON.stringify({ opportunities: opportunities.items, admissions: admissions.items, updates: updates.items });
    const result = await ai.generate({
      system: 'You are the EDUKEN CONSULT assistant. Answer only from the supplied platform context. Never invent facts or guarantee admissions, jobs, scholarships, visas or outcomes. Recommend official verification when needed.',
      prompt: 'Question: ' + question + '\nContext: ' + context,
      maxTokens: 600,
      temperature: 0.2
    });
    return json({ answer: result.text });
  }]
};